pipeline {
    agent any
	
	tools { 
        maven 'Maven-3.3.9' 
        jdk 'Open-JDK-11' 
        }	
	
    stages {
        
		        stage ('Build') {
            steps {
            echo 'Maven build is in progress.'
				    sh '''
                    echo "PATH = ${PATH}"
                    echo "M2_HOME = ${M2_HOME}"
                    echo "pwd = $(pwd)"        
                    cd ne-batch
                    echo "pwd = $(pwd)"
                    mvn clean install -Dmaven.test.skip=true
            '''
                  }
                  }
SonarQube Integration - sonarqube scanner for jenkins
Manag Jenkins- Configure system - SonarQube Servers - enable check box- sonarserver url - server authentication - secrest text code for authentication - 
            stage('SonarQube analysis') {
            steps {
            withSonarQubeEnv('SonarQube Server') {
            sh '''
                cd ne-batch
                mvn clean package sonar:sonar
            '''
                 }
                 } // SonarQube taskId is automatically attached to the pipeline context
                 }

            stage("Quality Gate"){
            steps {
            sleep time: 10000, unit: 'MILLISECONDS'
            timeout(time: 1, unit: 'MINUTES') { // Just in case something goes wrong, pipeline will be killed after a timeout
            waitForQualityGate abortPipeline: true
                 }
                 }
                 }   

		        stage ('Deploy Notify') {
            steps {
            // send to email
            emailext (
            from: 'wtg-ne-dev@charter.com',
			      to: 'c-karthiraja.gopalsamy1@charter.com',
			      subject: "NE DEV ne-batch Deployment STARTED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
            body: '${FILE,path="ne-batch/Templates/Initiation.html"}',
            recipientProviders: [[$class: 'RequesterRecipientProvider']]
                     )
                  }
                  }

            stage('Container Build') {
            steps {
		      	script{
                echo 'Container Build has been started...'
                sh 'cd ne-batch'
        				docker.build('wtg-ne-dev-reg' + ':ne-batch_5.4_v$BUILD_NUMBER','-f ne-batch/Dockerfile .')
                  }
			            }
                  }

            stage('Container Upload to GitLab') {
            steps {
            script{
                echo 'Image Push to GitLab has been started...'
                sh "docker tag wtg-ne-dev-reg:ne-batch_5.4_v${env.BUILD_NUMBER} panamax.spectrumxg.com/wtg-nbo-components/wtg-poc/5.4:ne-batch_v${env.BUILD_NUMBER}"
                sh "docker push panamax.spectrumxg.com/wtg-nbo-components/wtg-poc/5.4:ne-batch_v${env.BUILD_NUMBER}"
                  }
                  }
                  }

            stage('Container Cleanup') {
            steps {
            echo 'Image cleanup has been started...'
				    sh "docker rmi wtg-ne-dev-reg:ne-batch_5.4_v${env.BUILD_NUMBER}"
            sh "docker rmi panamax.spectrumxg.com/wtg-nbo-components/wtg-poc/5.4:ne-batch_v${env.BUILD_NUMBER}"
                  }
		              }

		         stage('Configmap Inject') {
			       steps {
			       echo 'Applying Properties and Datasource Configurations...'
             sh '''
                    cd ne-batch/devproperties
                    echo "pwd = $(pwd)"
                    kubectl create configmap ne-batch-properties --from-file=application.properties --namespace=wtg-ne-dev -o yaml --dry-run=client > application.yaml
                    kubectl apply -f application.yaml -n wtg-ne-dev
                    kubectl get configmaps ne-batch-properties -o yaml -n wtg-ne-dev
                '''
                  }
                  }

		          stage('EKS POD Deploy') {
			        steps {
			        echo 'POD Deployment has been started...'
              sh 'echo "pwd = $(pwd)"'
			        sh 'sed -i "s/{{BUILD_NUMBER}}/$BUILD_NUMBER/g" ne-batch/ne-batch-deployment.yaml'
              sh '''
                    echo "pwd = $(pwd)"
                    cd ne-batch
                    echo "pwd = $(pwd)"
                    kubectl apply -f ne-batch-deployment.yaml -n wtg-ne-dev
                    kubectl apply -f ne-batch-service.yaml -n wtg-ne-dev
                '''
                  }
                  }

		          stage('EKS POD Status') {
		          steps {
			        echo 'POD Status is being monitored...'
			        //sleep(time: 120, unit: "SECONDS")
			        //sh 'kubectl get pods -A | grep verizon-deployment'
              sh 'kubectl rollout status deployment ne-batch-deployment -n wtg-ne-dev --watch --timeout=5m'
			            }
		              }
                  } // Closing Stages 

              post {
              success {
              emailext (
              from: 'wtg-ne-dev@charter.com',
		          to: 'c-karthiraja.gopalsamy1@charter.com',
		          attachLog: true,
		          subject: "NE DEV ne-batch Deployment SUCCESSFUL: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
              body: '${FILE,path="ne-batch/Templates/Completion.html"}',
              recipientProviders: [[$class: 'RequesterRecipientProvider']]
                       )
                      }

              failure {
              emailext (
              from: 'wtg-ne-dev@charter.com',
		          to: 'c-karthiraja.gopalsamy1@charter.com',
		          attachLog: true,
		          subject: "NE DEV ne-batch Deployment FAILED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
              body: '${FILE,path="ne-batch/Templates/Failure.html"}',
              recipientProviders: [[$class: 'RequesterRecipientProvider']]
                       )
                      } 
                  } // Closing Post
} // Clossing Pipeline


Jenkins - Dynamic Parametrization _ Multi-Option Parameters _ Active - Reactive Parameters
Active choics plugins
Then you can see below 
This Project is parameterized - Active choice parameter/Active choice reactive parameter
return [
'Prod','QA','Dev'
]

if (env.equqls("Prod")){
return ["Prod1"]
}
else if (env.equqls("QA")){
return ["QA1","QA2"]
}
else if (env.equqls("Dev")){
return ["Dev1","Dev2"]
}
else {
return ["Select a server from dropdown"]
}

if (sub_env.equals("Prod")) {
return ["Prod-Ser-1","Prod-Ser-1"]
}
************************SharedLibrary---------------

Code reusability 
•	vars (M)
•	src (M)
•	resources


def call(String name = 'User') {
		echo "Welcome, ${name}."
}

// Jenkinsfile
@Library('first-shared-lib') _
welcomeJob ‘lambdatest’


stage {
}
So, Together, the scripted pipeline can be written as mentioned below.
node ('node-1') {
  stage('Source') {
    git 'https://github.com/digitalvarys/jenkins-tutorials.git''
  }
  stage('Compile') { 
    def gradle_home = tool 'gradle4'
    sh "'${gradle_home}/bin/gradle' clean compileJava test"
  }
}